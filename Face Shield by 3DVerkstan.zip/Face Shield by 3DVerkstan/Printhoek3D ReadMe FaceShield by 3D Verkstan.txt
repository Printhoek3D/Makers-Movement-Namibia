Face Shield by 3D Verkstan

Get More Information Here:

https://3dprint.nih.gov/discover/3dpx-013306

More information can be found at the designers web site:

https://3dverkstan.se/protective-visor/

You can also find the files and license here:

https://github.com/Cederb/Faceshield.nu/

_________________________________________________________

Bill of Materials:

Transparent Film at A4 Size 
PLA, PETG 3D Printing Material