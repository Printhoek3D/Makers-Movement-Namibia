For more information, please contact Printhoek 3D

Contact Person: Romar Quitasol
Mobile: 081 2898 147

Contact Person: Raymond van Schalkwyk 
Mobile: 081 3333 963

Email: fightcovid19@printhoek3d.com

This is a Remixed Design made by Ken Lord aka Suraky

_____________________________________________________

His work can be found here:

https://www.thingiverse.com/thing:4249113

_____________________________________________________

Bill of Materials

PLA,PETG 3D Printing Material
