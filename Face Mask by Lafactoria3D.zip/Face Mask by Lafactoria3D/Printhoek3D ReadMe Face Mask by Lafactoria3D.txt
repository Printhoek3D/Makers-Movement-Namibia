Face Mask by Lafactoria3D

Get More Information Here:

https://www.thingiverse.com/thing:4225667


___________________________________________________________________________________


Bill of Materials:

3D Materials - PLA (Polyactic Acid)

Elastic Cord 8-12mm Widths. Length Required = 2x 400mm

Foam Soal at 10mm Width, ranging from 3-10mm in Thickness. Length Required = 400mm

Cotton Fabric at 50x50mm Can be doubled in quantity to have 2-ply Cotton. 