Surgical Mask Strap by Ken Lord aka Suraky

Get More Information Here:

https://3dprint.nih.gov/discover/3dpx-013410

https://www.thingiverse.com/thing:4249113

https://www.thingiverse.com/Suraky/about

____________________________________________

Bill of Materials

PLA,PETG 3D Printing Material